// Variáveis para os peixes (1 a 3 aleatórios)
let peixes = []; // Array de objetos peixe
const velocidadePeixe = 1;
let peixeImage = null;
let peixeWidth = 0;
let peixeHeight = 0;
let quantidadePeixes = 0; // Quantidade aleatória entre 1-3

// Variáveis para o cavalo-marinho
let cavaloMarinhoY = 200; // Posição Y inicial
let velocidadeCavaloMarinho = 0.5; // Velocidade vertical
let direcaoCavaloMarinho = 1; // 1 para baixo, -1 para cima
let cavaloMarinhoImage = null;
let cavaloMarinhoX = 635; // Posição X fixa (centro do canvas)
let cavaloMarinhoHeight = 0;

// Variáveis para os cardumes (até 3 de cada tipo)
let cardumes = []; // Array de objetos cardume
let velocidadeCardume = 1; // Velocidade horizontal
let cardumeImage1 = null; // cardume1.png (vai para direita)
let cardumeImage2 = null; // cardume2.png (vai para esquerda)
let cardumeWidth = 0;
let cardumeHeight = 0;
const maxCardumes = 3;

// Variáveis para o mergulhador
let mergulhadorX = 0; // Será inicializado quando a imagem carregar
let mergulhadorY = 350; // Posição Y fixa
let velocidadeMergulhador = 1; // Velocidade horizontal (para esquerda)
let mergulhadorImage = null;
let mergulhadorWidth = 0;
let mergulhadorAtivo = false; // Controla se o mergulhador ainda está visível

// Carregar a imagem do peixe
function carregarPeixe() {
  peixeImage = new Image();
  peixeImage.src = "img/peixe1.png";

  peixeImage.onload = function () {
    peixeWidth = peixeImage.width;
    peixeHeight = peixeImage.height;
    // Inicializar alguns peixes
    inicializarPeixes();
  };
}

// Carregar a imagem do cavalo-marinho
function carregarCavaloMarinho() {
  cavaloMarinhoImage = new Image();
  cavaloMarinhoImage.src = "img/cavalo-marinho.png";

  cavaloMarinhoImage.onload = function () {
    cavaloMarinhoHeight = cavaloMarinhoImage.height;
  };
}

// Carregar as imagens do cardume
function carregarCardume() {
  cardumeImage1 = new Image();
  cardumeImage1.src = "img/cardume1.png";

  cardumeImage2 = new Image();
  cardumeImage2.src = "img/cardume2.png";

  cardumeImage1.onload = function () {
    cardumeWidth = cardumeImage1.width;
    cardumeHeight = cardumeImage1.height;
    // Inicializar alguns cardumes
    inicializarCardumes();
  };

  cardumeImage2.onload = function () {
    // Se cardume1 ainda não carregou, usar cardume2 como referência
    if (cardumeWidth === 0) {
      cardumeWidth = cardumeImage2.width;
      cardumeHeight = cardumeImage2.height;
    }
  };
}

// Carregar a imagem do mergulhador
function carregarMergulhador() {
  mergulhadorImage = new Image();
  mergulhadorImage.src = "img/mergulhador.png";

  mergulhadorImage.onload = function () {
    mergulhadorWidth = mergulhadorImage.width;
    // Inicializar posição X no lado direito do canvas
    const canvas = document.getElementById("canvas");
    mergulhadorX = canvas.width;
    mergulhadorAtivo = true;
  };
}

// Função para inicializar peixes
function inicializarPeixes() {
  const canvas = document.getElementById("canvas");
  peixes = [];
  // Quantidade aleatória entre 1 e 3
  quantidadePeixes = Math.floor(Math.random() * 3) + 1;
  
  for (let i = 0; i < quantidadePeixes; i++) {
    const peixe = {
      x: Math.random() * canvas.width,
      y: Math.random() * (canvas.height - 200) + 120, // Evitar área dos textos
      velocidade: velocidadePeixe
    };
    peixes.push(peixe);
  }
}

// Função para desenhar os peixes de forma seamless
function desenharPeixeSeamless(ctx, canvas) {
  if (!peixeImage || !peixeImage.complete) return;

  peixes.forEach((peixe) => {
    // Calcular a posição usando módulo para criar loop seamless
    let posX = peixe.x % (canvas.width + peixeWidth);

    // Desenhar o peixe na posição atual
    ctx.drawImage(peixeImage, posX, peixe.y);

    // Se o peixe está atravessando a borda direita, desenhar uma cópia à esquerda
    if (posX + peixeWidth > canvas.width) {
      let offsetX = posX - (canvas.width + peixeWidth);
      ctx.drawImage(peixeImage, offsetX, peixe.y);
    }
  });
}

// Função para desenhar o cavalo-marinho
function desenharCavaloMarinho(ctx, canvas) {
  if (!cavaloMarinhoImage || !cavaloMarinhoImage.complete) return;

  // Desenhar o cavalo-marinho na posição atual
  ctx.drawImage(cavaloMarinhoImage, cavaloMarinhoX, cavaloMarinhoY);
}

// Função para inicializar cardumes
function inicializarCardumes() {
  const canvas = document.getElementById("canvas");
  cardumes = [];
  
  // Criar até 3 cardumes indo para direita (cardume1)
  for (let i = 0; i < maxCardumes; i++) {
    const cardume = {
      x: -cardumeWidth - Math.random() * 500, // Começar fora da tela à esquerda
      y: Math.random() * (canvas.height - 200) + 120,
      direcao: 1, // Para direita
      imagem: cardumeImage1
    };
    cardumes.push(cardume);
  }
  
  // Criar até 3 cardumes indo para esquerda (cardume2)
  for (let i = 0; i < maxCardumes; i++) {
    const cardume = {
      x: canvas.width + Math.random() * 500, // Começar fora da tela à direita
      y: Math.random() * (canvas.height - 200) + 120,
      direcao: -1, // Para esquerda
      imagem: cardumeImage2
    };
    cardumes.push(cardume);
  }
}

// Função para desenhar os cardumes
function desenharCardume(ctx, canvas) {
  if (!cardumeImage1 || !cardumeImage2) return;

  cardumes.forEach((cardume) => {
    if (cardume.imagem && cardume.imagem.complete) {
      // Desenhar o cardume apenas se estiver visível na tela
      if (cardume.x + cardumeWidth >= -cardumeWidth && cardume.x <= canvas.width + cardumeWidth) {
        ctx.drawImage(cardume.imagem, cardume.x, cardume.y);
      }
    }
  });
}

// Função para desenhar o mergulhador
function desenharMergulhador(ctx, canvas) {
  if (!mergulhadorAtivo || !mergulhadorImage || !mergulhadorImage.complete) return;

  // Desenhar o mergulhador apenas se ainda estiver visível na tela
  if (mergulhadorX + mergulhadorWidth >= 0) {
    ctx.drawImage(mergulhadorImage, mergulhadorX, mergulhadorY);
  }
}

// Função para atualizar a posição dos peixes
function atualizarPeixe() {
  const canvas = document.getElementById("canvas");
  
  peixes.forEach((peixe) => {
    peixe.x += peixe.velocidade;
    
    // Resetar quando necessário para manter números pequenos
    if (peixe.x > canvas.width + peixeWidth) {
      peixe.x = peixe.x % (canvas.width + peixeWidth);
    }
  });
  
  // Manter a quantidade inicial de peixes, spawnar novos se necessário
  while (peixes.length < quantidadePeixes) {
    const novoPeixe = {
      x: -peixeWidth - Math.random() * 200,
      y: Math.random() * (canvas.height - 200) + 120,
      velocidade: velocidadePeixe
    };
    peixes.push(novoPeixe);
  }
}

// Função para atualizar a posição do cavalo-marinho
function atualizarCavaloMarinho() {
  const canvas = document.getElementById("canvas");

  // Mover o cavalo-marinho na direção atual
  cavaloMarinhoY += velocidadeCavaloMarinho * direcaoCavaloMarinho;

  // Verificar limites superior e inferior
  if (cavaloMarinhoY <= 0) {
    // Chegou ao topo, inverter para baixo
    cavaloMarinhoY = 0;
    direcaoCavaloMarinho = 1;
  } else if (cavaloMarinhoY + cavaloMarinhoHeight >= canvas.height) {
    // Chegou ao fundo, inverter para cima
    cavaloMarinhoY = canvas.height - cavaloMarinhoHeight;
    direcaoCavaloMarinho = -1;
  }
}

// Função para atualizar a posição dos cardumes
function atualizarCardume() {
  const canvas = document.getElementById("canvas");

  cardumes.forEach((cardume) => {
    // Mover o cardume na direção atual
    cardume.x += velocidadeCardume * cardume.direcao;

    // Se saiu completamente da tela, resetar do outro lado
    if (cardume.direcao === 1 && cardume.x > canvas.width + cardumeWidth) {
      // Cardume indo para direita saiu pela direita, resetar à esquerda
      cardume.x = -cardumeWidth - Math.random() * 500;
      cardume.y = Math.random() * (canvas.height - 200) + 120;
      cardume.imagem = cardumeImage1;
    } else if (cardume.direcao === -1 && cardume.x < -cardumeWidth) {
      // Cardume indo para esquerda saiu pela esquerda, resetar à direita
      cardume.x = canvas.width + Math.random() * 500;
      cardume.y = Math.random() * (canvas.height - 200) + 120;
      cardume.imagem = cardumeImage2;
    }
  });
  
  // Manter sempre 3 cardumes de cada tipo
  const cardumesDireita = cardumes.filter(c => c.direcao === 1);
  const cardumesEsquerda = cardumes.filter(c => c.direcao === -1);
  
  if (cardumesDireita.length < maxCardumes) {
    const novoCardume = {
      x: -cardumeWidth - Math.random() * 500,
      y: Math.random() * (canvas.height - 200) + 120,
      direcao: 1,
      imagem: cardumeImage1
    };
    cardumes.push(novoCardume);
  }
  
  if (cardumesEsquerda.length < maxCardumes) {
    const novoCardume = {
      x: canvas.width + Math.random() * 500,
      y: Math.random() * (canvas.height - 200) + 120,
      direcao: -1,
      imagem: cardumeImage2
    };
    cardumes.push(novoCardume);
  }
}

// Função para atualizar a posição do mergulhador
function atualizarMergulhador() {
  if (!mergulhadorAtivo) return;

  // Mover o mergulhador para a esquerda
  mergulhadorX -= velocidadeMergulhador;

  // Se saiu completamente da tela, desativar
  if (mergulhadorX + mergulhadorWidth < 0) {
    mergulhadorAtivo = false;
  }
}

// Funções para obter posições dos peixes (para detecção de colisão)
function obterPosicoesPeixes() {
  const canvas = document.getElementById("canvas");
  const posicoes = [];
  
  peixes.forEach((peixe) => {
    let posX = peixe.x % (canvas.width + peixeWidth);
    posicoes.push({ x: posX, y: peixe.y, width: peixeWidth, height: peixeHeight });
    
    // Verificar cópia seamless
    if (posX + peixeWidth > canvas.width) {
      posicoes.push({ 
        x: posX - (canvas.width + peixeWidth), 
        y: peixe.y, 
        width: peixeWidth, 
        height: peixeHeight 
      });
    }
  });
  
  return posicoes;
}

function obterPosicaoCavaloMarinho() {
  return { x: cavaloMarinhoX, y: cavaloMarinhoY, width: cavaloMarinhoImage ? cavaloMarinhoImage.width : 0, height: cavaloMarinhoHeight };
}

function obterPosicoesCardumes() {
  return cardumes.map((cardume) => ({
    x: cardume.x,
    y: cardume.y,
    width: cardumeWidth,
    height: cardumeHeight
  }));
}

// Iniciar quando o DOM estiver pronto
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function () {
    carregarPeixe();
    carregarCavaloMarinho();
    carregarCardume();
    carregarMergulhador();
  });
} else {
  carregarPeixe();
  carregarCavaloMarinho();
  carregarCardume();
  carregarMergulhador();
}
