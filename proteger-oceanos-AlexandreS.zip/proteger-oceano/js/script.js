// Obter o canvas e seu contexto
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// Definir o tamanho do canvas
canvas.width = 980;
canvas.height = 581;

// Variáveis do jogo
let pontuacao = 0;
let mouseX = 0;
let mouseY = 0;
let crosshairImage = null;
let gameOver = false; // Controla se o jogo acabou
let tempoInicio = 0; // Tempo de início do jogo
const tempoLimite = 60000; // 1 minuto em milissegundos

// Fator de escala para reduzir tamanho das imagens
const escalaLixo = 0.1; // 10% do tamanho original
const escalaCrosshair = 0.1; // 15% do tamanho original

// Variáveis do lixo
let lixos = []; // Array de objetos de lixo
let proximoSpawnLixo = 0; // Tempo para próximo spawn
const tiposLixo = ["garrafa.png", "lata.png", "rede.png", "saco.png", "plastico.png"];
let imagensLixo = {}; // Cache de imagens do lixo

// Carregar a imagem de fundo
const backgroundImage = new Image();
backgroundImage.src = "img/fundo.png";

// Carregar crosshair
crosshairImage = new Image();
crosshairImage.src = "img/crosshair.png";

// Carregar imagens do lixo
tiposLixo.forEach((tipo) => {
  const img = new Image();
  img.src = `img/${tipo}`;
  imagensLixo[tipo] = img;
});

// Função para spawnar lixo aleatório
function spawnarLixo() {
  // Não spawnar mais lixo se o jogo acabou
  if (gameOver) return;
  
  const tipoAleatorio = tiposLixo[Math.floor(Math.random() * tiposLixo.length)];
  const img = imagensLixo[tipoAleatorio];
  
  if (!img || !img.complete) return;

  // Calcular tamanho reduzido
  const widthReduzido = img.width * escalaLixo;
  const heightReduzido = img.height * escalaLixo;

  const lixo = {
    x: Math.random() * (canvas.width - widthReduzido),
    y: Math.random() * (canvas.height - heightReduzido - 100) + 100, // Evitar área dos textos
    tipo: tipoAleatorio,
    width: widthReduzido,
    height: heightReduzido,
    imagem: img
  };
  
  lixos.push(lixo);
  
  // Verificar se chegou a 20 lixos
  if (lixos.length >= 20) {
    gameOver = true;
  }
}

// Função para desenhar o lixo
function desenharLixo() {
  lixos.forEach((lixo) => {
    if (lixo.imagem && lixo.imagem.complete) {
      // Desenhar com tamanho reduzido
      ctx.drawImage(lixo.imagem, lixo.x, lixo.y, lixo.width, lixo.height);
    }
  });
}

// Função para desenhar o crosshair
function desenharCrosshair() {
  if (crosshairImage && crosshairImage.complete) {
    // Calcular tamanho reduzido
    const crosshairWidth = crosshairImage.width * escalaCrosshair;
    const crosshairHeight = crosshairImage.height * escalaCrosshair;
    
    // Centralizar o crosshair no cursor
    const crosshairX = mouseX - crosshairWidth / 2;
    const crosshairY = mouseY - crosshairHeight / 2;
    
    // Desenhar com tamanho reduzido
    ctx.drawImage(crosshairImage, crosshairX, crosshairY, crosshairWidth, crosshairHeight);
  }
}

// Função para desenhar a pontuação
function desenharPontuacao() {
  ctx.fillStyle = "white";
  ctx.font = "bold 30px Arial";
  ctx.textAlign = "left";
  ctx.fillText(`Pontos: ${pontuacao}`, 20, canvas.height - 20);
}

// Função para desenhar o temporizador
function desenharTemporizador() {
  if (tempoInicio === 0 || gameOver) return;
  
  const tempoDecorrido = Date.now() - tempoInicio;
  const tempoRestante = Math.max(0, tempoLimite - tempoDecorrido);
  const segundosRestantes = Math.ceil(tempoRestante / 1000);
  
  ctx.fillStyle = "white";
  ctx.font = "20px Arial";
  ctx.textAlign = "left";
  ctx.fillText(`Tempo: ${segundosRestantes}s`, 20, 115);
}

// Função para desenhar GAME OVER
function desenharGameOver() {
  if (!gameOver) return;
  
  // Desenhar fundo semi-transparente
  ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Desenhar texto GAME OVER
  ctx.fillStyle = "red";
  ctx.font = "bold 80px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("GAME OVER", canvas.width / 2, canvas.height / 2 - 50);
  
  // Desenhar pontuação abaixo
  ctx.fillStyle = "white";
  ctx.font = "bold 50px Arial";
  ctx.fillText(`Pontuação: ${pontuacao}`, canvas.width / 2, canvas.height / 2 + 50);
  
  // Resetar alinhamento
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
}

// Função para verificar colisão ponto-retângulo
function verificarColisao(x, y, obj) {
  return (
    x >= obj.x &&
    x <= obj.x + obj.width &&
    y >= obj.y &&
    y <= obj.y + obj.height
  );
}

// Função para verificar clique em peixes
function verificarCliquePeixes(x, y) {
  // Verificar todos os peixes (peixe1.png)
  if (typeof obterPosicoesPeixes === "function") {
    const posicoesPeixes = obterPosicoesPeixes();
    for (let i = 0; i < posicoesPeixes.length; i++) {
      if (verificarColisao(x, y, posicoesPeixes[i])) {
        return true;
      }
    }
  }

  // Verificar cavalo-marinho
  if (typeof obterPosicaoCavaloMarinho === "function") {
    const posCavalo = obterPosicaoCavaloMarinho();
    if (verificarColisao(x, y, posCavalo)) {
      return true;
    }
  }

  // Verificar todos os cardumes (cardume1.png e cardume2.png)
  if (typeof obterPosicoesCardumes === "function") {
    const posicoesCardumes = obterPosicoesCardumes();
    for (let i = 0; i < posicoesCardumes.length; i++) {
      if (verificarColisao(x, y, posicoesCardumes[i])) {
        return true;
      }
    }
  }

  return false;
}

// Função para verificar clique no lixo
function verificarCliqueLixo(x, y) {
  for (let i = lixos.length - 1; i >= 0; i--) {
    const lixo = lixos[i];
    if (verificarColisao(x, y, lixo)) {
      lixos.splice(i, 1); // Remover o lixo
      return true;
    }
  }
  return false;
}

// Event listener para mouse move
canvas.addEventListener("mousemove", (e) => {
  const rect = canvas.getBoundingClientRect();
  mouseX = e.clientX - rect.left;
  mouseY = e.clientY - rect.top;
});

// Event listener para clique
canvas.addEventListener("click", (e) => {
  // Não processar cliques se o jogo acabou
  if (gameOver) return;
  
  const rect = canvas.getBoundingClientRect();
  const clickX = e.clientX - rect.left;
  const clickY = e.clientY - rect.top;

  // Verificar clique no lixo primeiro (+10 pontos)
  if (verificarCliqueLixo(clickX, clickY)) {
    pontuacao += 10;
    return;
  }

  // Verificar clique nos peixes (-20 pontos)
  if (verificarCliquePeixes(clickX, clickY)) {
    pontuacao -= 20;
    if (pontuacao < 0) pontuacao = 0; // Não permitir pontuação negativa
  }
});


// Função para desenhar tudo
function desenhar() {
  // Desenhar a imagem de fundo
  ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);

  // Configurar o texto
  ctx.fillStyle = "white";
  ctx.font = "40px Arial";

  // Desenhar o texto no centro do canvas
  ctx.fillText("Proteger os Oceanos", 20, 50);

  // Configurar fonte menor para o texto do autor
  ctx.font = "20px Arial";

  // Desenhar o texto do autor abaixo
  ctx.fillText("Autor: Alexandre D. Smigon, nº:1", 20, 90);

  // Desenhar o temporizador
  desenharTemporizador();

  // Desenhar o peixe seamless (função do formas.js)
  if (typeof desenharPeixeSeamless === "function") {
    desenharPeixeSeamless(ctx, canvas);
  }

  // Desenhar o cavalo-marinho (função do formas.js)
  if (typeof desenharCavaloMarinho === "function") {
    desenharCavaloMarinho(ctx, canvas);
  }

  // Desenhar o cardume (função do formas.js)
  if (typeof desenharCardume === "function") {
    desenharCardume(ctx, canvas);
  }

  // Desenhar o mergulhador (função do formas.js)
  if (typeof desenharMergulhador === "function") {
    desenharMergulhador(ctx, canvas);
  }

  // Desenhar o lixo
  desenharLixo();

  // Desenhar a pontuação
  desenharPontuacao();

  // Desenhar o crosshair por último (sobre tudo)
  desenharCrosshair();
  
  // Desenhar GAME OVER se o jogo acabou
  desenharGameOver();
}

// Função de animação
function animar() {
  // Limpar o canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Verificar se o tempo acabou
  if (!gameOver && tempoInicio > 0) {
    const tempoDecorrido = Date.now() - tempoInicio;
    if (tempoDecorrido >= tempoLimite) {
      gameOver = true;
    }
  }

  // Atualizar spawn de lixo (só se o jogo não acabou)
  if (!gameOver) {
    const agora = Date.now();
    if (agora > proximoSpawnLixo) {
      spawnarLixo();
      // Próximo spawn entre 1 e 3 segundos
      proximoSpawnLixo = agora + (Math.random() * 2000 + 1000);
    }
  }

  // Desenhar tudo
  desenhar();

  // Atualizar posição do peixe (função do formas.js)
  if (typeof atualizarPeixe === "function") {
    atualizarPeixe();
  }

  // Atualizar posição do cavalo-marinho (função do formas.js)
  if (typeof atualizarCavaloMarinho === "function") {
    atualizarCavaloMarinho();
  }

  // Atualizar posição do cardume (função do formas.js)
  if (typeof atualizarCardume === "function") {
    atualizarCardume();
  }

  // Atualizar posição do mergulhador (função do formas.js)
  if (typeof atualizarMergulhador === "function") {
    atualizarMergulhador();
  }

  // Continuar a animação
  requestAnimationFrame(animar);
}

// Quando a imagem de fundo carregar, iniciar a animação
backgroundImage.onload = function () {
  tempoInicio = Date.now(); // Iniciar o timer
  proximoSpawnLixo = Date.now() + 2000; // Primeiro spawn após 2 segundos
  animar();
};
